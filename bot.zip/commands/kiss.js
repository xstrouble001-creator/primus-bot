import axios from 'axios';

const command = {
    name: 'kiss',
    aliases: ['muah'],
    category: 'fun',
    description: 'Send an animated kiss GIF/video.',
    execute: async (sock, msg, args, context) => {
        const { from, sender } = context;

        let target = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || 
                     msg.message?.extendedTextMessage?.contextInfo?.participant;

        if (!target && args[0]) {
            target = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        }

        try {
            // Using a reliable anime GIF/video API (waifu.pics)
            const response = await axios.get('https://api.waifu.pics/sfw/kiss');
            const gifUrl = response.data.url;

            let caption = target 
                ? `💋 @${sender.split('@')[0]} kissed @${target.split('@')[0]}!`
                : `💋 @${sender.split('@')[0]} blows a kiss!`;

            // WhatsApp requires gifPlayback: true and fetching as buffer/url
            await sock.sendMessage(from, { 
                video: { url: gifUrl }, 
                gifPlayback: true, 
                caption: caption,
                mentions: target ? [sender, target] : [sender]
            }, { quoted: msg });

        } catch (err) {
            console.error('❌ Kiss command error:', err.message);
            await sock.sendMessage(from, { text: '❌ Failed to fetch kiss GIF. Try again shortly!' }, { quoted: msg });
        }
    }
};

export default command;
