import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import config from '../config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'public',
    description: 'To make the bot accessible to everyone, owner only command',
    category: 'settings',
    execute: async (sock, msg, args, context) => {
        const { from, isOwner } = context;
        if (!isOwner) {
            return await sock.sendMessage(from, { text: '⚠️ [ACCESS DENIED] Root privilege required for network override.' }, { quoted: msg });
        }

        config.workMode = 'public';

        try {
            const configPath = path.resolve(__dirname, '../config.js');
            let configContent = fs.readFileSync(configPath, 'utf8');

            if (configContent.includes('workMode')) {
                configContent = configContent.replace(/workMode\s*:\s*['"`].*?['"`]/, `workMode: 'public'`);
            } else {
                configContent = configContent.replace(/export default\s*{/, `export default {\n    workMode: 'public',`);
            }
            fs.writeFileSync(configPath, configContent, 'utf8');
        } catch (err) {
            console.error('Failed to update config.js file:', err);
        }

        await sock.sendMessage(from, { text: '🌐 [NETWORK STATUS: PUBLIC] Security perimeter lowered. All nodes granted access.' }, { quoted: msg });
    }
};
