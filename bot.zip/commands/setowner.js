import { loadSettings, saveSettings } from '../lib/database.js';

export default {
    name: 'setowner',
category: 'alpha',
    description: 'Add a new owner by phone number',
    ownerOnly: true,
    execute: async (sock, msg, args, context) => {
        const target = args[0]?.replace(/[^0-9]/g, '');
        if (!target) {
            await sock.sendMessage(context.from, { text: '❌ Please provide a phone number.\nExample: `.setowner 2348039336009`' }, { quoted: msg });
            return;
        }

        const settings = loadSettings() || { owners: [], sudo: [] };
        if (!settings.owners) settings.owners = [];

        if (settings.owners.includes(target)) {
            await sock.sendMessage(context.from, { text: `⚠️ The number +${target} is already an owner.` }, { quoted: msg });
            return;
        }

        settings.owners.push(target);
        saveSettings(settings);

        await sock.sendMessage(context.from, { text: `✅ Successfully added +${target} as a bot owner!` }, { quoted: msg });
    }
};
