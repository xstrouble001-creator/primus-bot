import { handleClaim } from './pixelbomb.js';

export default {
    name: 'claim',
    category: 'games',
    description: 'Claim a cell coordinate in Pixel Bomb.',
    execute: async (sock, msg, args, context) => {
        await handleClaim(sock, msg, args, context);
    }
};
