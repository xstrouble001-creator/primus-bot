import { loadSettings, saveSettings } from '../lib/database.js';

export default {
    name: 'antilink',
category: 'group',
    description: 'Toggle antilink protection in the group',
    groupOnly: true,
    execute: async (sock, msg, args, context) => {
        const { from } = context;
        const settings = loadSettings() || {};
        if (!settings.antilinkGroups) settings.antilinkGroups = [];

        const isEnabled = settings.antilinkGroups.includes(from);
        const action = args[0]?.toLowerCase();

        if (action === 'on' && !isEnabled) {
            settings.antilinkGroups.push(from);
            saveSettings(settings);
            await sock.sendMessage(from, { text: '🛡️ [ANTILINK ACTIVATED] Foreign links sent by non-admins will now be automatically eradicated.' }, { quoted: msg });
        } else if (action === 'off' && isEnabled) {
            settings.antilinkGroups = settings.antilinkGroups.filter(id => id !== from);
            saveSettings(settings);
            await sock.sendMessage(from, { text: '⚠️ [ANTILINK DEACTIVATED] Links are now permitted in this sector.' }, { quoted: msg });
        } else {
            await sock.sendMessage(from, { text: `🛡️ [ANTILINK STATUS] Currently: *${isEnabled ? 'ACTIVE' : 'INACTIVE'}*\nUse \`.antilink on\` or \`.antilink off\` to toggle.` }, { quoted: msg });
        }
    }
};
