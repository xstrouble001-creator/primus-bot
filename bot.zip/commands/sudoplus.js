import { loadSettings, saveSettings } from '../lib/database.js';

export default {
    name: 'sudoplus',
    aliases: ['sudo+'],
    category: 'settings',
    desc: 'Grant full owner-level access to a user (Host Number Only)',
    execute: async (sock, msg, args, context) => {
        const { from, sender, sessionName } = context;

        // Strictly verify that the sender IS the host account itself
        const botOwnerJid = sock.user?.id || '';
        const botNumber = botOwnerJid.split(':')[0].split('@')[0].replace(/[^0-9]/g, '');
        const senderNum = sender.split('@')[0].replace(/[^0-9]/g, '');

        const isLinkedDevice = msg.key.fromMe || senderNum === botNumber;

        if (!isLinkedDevice) {
            await sock.sendMessage(from, { 
                text: '❌ *Access Denied:* Only the primary linked device host account can execute #sudo+.' 
            }, { quoted: msg });
            return;
        }

        // Determine target number via tag, reply, or raw string argument
        let target = '';
        const mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;

        if (mentionedJid) {
            target = mentionedJid.split('@')[0];
        } else if (quotedParticipant) {
            target = quotedParticipant.split('@')[0];
        } else if (args[0]) {
            target = args[0].replace(/[^0-9]/g, '');
        }

        if (!target) {
            await sock.sendMessage(from, { 
                text: '⚠️ *Usage:* `#sudo+ @user` or reply to a message with `#sudo+`' 
            }, { quoted: msg });
            return;
        }

        const settings = loadSettings() || {};
        if (!Array.isArray(settings.owners)) {
            settings.owners = [];
        }

        if (settings.owners.includes(target)) {
            await sock.sendMessage(from, { 
                text: `⚠️ @${target} is already registered in the Owner database list.`,
                mentions: [`${target}@s.whatsapp.net`] 
            }, { quoted: msg });
            return;
        }

        // Elevate user to Full Owner
        settings.owners.push(target);
        saveSettings(settings);

        await sock.sendMessage(from, { 
            text: `👑 *FULL OWNER ACCESS GRANTED!*\n\nUser @${target} has been added to the Owners list. They now have unrestricted access to all bot commands!`,
            mentions: [`${target}@s.whatsapp.net`]
        }, { quoted: msg });
    }
};
