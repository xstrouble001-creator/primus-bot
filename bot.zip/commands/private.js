import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import config from '../config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'private',
    description: 'To privatize the bot to only owner and sudo users to use command, owner only command',
    category: 'settings',
    execute: async (sock, msg, args, context) => {
        const { from, isOwner } = context;
        if (!isOwner) {
            return await sock.sendMessage(from, { text: '❌ This command is restricted to the bot owner.' }, { quoted: msg });
        }

        config.workMode = 'private';

        try {
            const configPath = path.resolve(__dirname, '../config.js');
            let configContent = fs.readFileSync(configPath, 'utf8');
            if (configContent.includes('workMode')) {
                configContent = configContent.replace(/workMode\s*:\s*['"`].*?['"`]/, `workMode: 'private'`);
            } else {
                configContent = configContent.replace(/export default\s*{/, `export default {\n    workMode: 'private',`);
            }
            fs.writeFileSync(configPath, configContent, 'utf8');
        } catch (err) {
            console.error('Failed to update config.js file:', err);
        }

        await sock.sendMessage(from, { text: '🔒 Bot mode switched to **Private**. Only owner and sudo users can execute commands.' }, { quoted: msg });
    }
};
