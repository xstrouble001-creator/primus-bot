import { renderWSGGrid } from '../lib/wsgCanvas.js';

const WORD_DICTIONARY = [
    'BOT', 'NODE', 'TERMUX', 'PRIMUS', 'JAVASCRIPT', 'CYBER', 'BAILEYS', 'WA',
    'SERVERS', 'DATABASE', 'SCRIPT', 'PYTHON', 'PIXEL', 'SHELL', 'SYSTEM'
];

function generateWordSearch(gridSize = 10, wordCount = 5) {
    const grid = Array.from({ length: gridSize }, () => Array(gridSize).fill(''));
    const selectedWords = [...WORD_DICTIONARY].sort(() => 0.5 - Math.random()).slice(0, wordCount);
    const directions = [
        [0, 1],   // Horizontal
        [1, 0],   // Vertical
        [1, 1],   // Diagonal Down-Right
        [-1, 1]   // Diagonal Up-Right
    ];

    const wordLocations = [];

    for (const word of selectedWords) {
        let placed = false;
        let attempts = 0;
        while (!placed && attempts < 100) {
            attempts++;
            const dir = directions[Math.floor(Math.random() * directions.length)];
            const row = Math.floor(Math.random() * gridSize);
            const col = Math.floor(Math.random() * gridSize);

            const endRow = row + dir[0] * (word.length - 1);
            const endCol = col + dir[1] * (word.length - 1);

            if (endRow >= 0 && endRow < gridSize && endCol >= 0 && endCol < gridSize) {
                let canPlace = true;
                for (let i = 0; i < word.length; i++) {
                    const r = row + dir[0] * i;
                    const c = col + dir[1] * i;
                    if (grid[r][c] !== '' && grid[r][c] !== word[i]) {
                        canPlace = false;
                        break;
                    }
                }

                if (canPlace) {
                    const cells = [];
                    for (let i = 0; i < word.length; i++) {
                        const r = row + dir[0] * i;
                        const c = col + dir[1] * i;
                        grid[r][c] = word[i];
                        cells.push({ row: r, col: c });
                    }
                    wordLocations.push({ word, cells });
                    placed = true;
                }
            }
        }
    }

    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    for (let r = 0; r < gridSize; r++) {
        for (let c = 0; c < gridSize; c++) {
            if (grid[r][c] === '') {
                grid[r][c] = alphabet[Math.floor(Math.random() * alphabet.length)];
            }
        }
    }

    return { grid, words: selectedWords, wordLocations };
}

export function formatWordList(words, foundWords) {
    return words.map(w => foundWords.includes(w) ? `~${w}~ ❌` : `*${w}* 🟩`).join('\n');
}

export default {
    name: 'wsg',
    description: 'Start a Word Search game in the chat',
    category: 'games',
    execute: async (sock, msg, args, context) => {
        const { from, isGroup } = context;

        if (!isGroup) {
            await sock.sendMessage(from, { text: '⚠️ 𝚃𝚑𝚒𝚜  𝚐𝚊𝚖𝚎  𝚌𝚊𝚗  𝚘𝚗𝚕𝚢  𝚋𝚎  𝚙𝚕𝚊𝚢𝚎𝚍  𝚒𝚗  𝚐𝚛𝚘𝚞𝚙  𝚌𝚑𝚊𝚝𝚜!' }, { quoted: msg });
            return;
        }

        if (!global.wsgGames) global.wsgGames = {};

        if (global.wsgGames[from]) {
            await sock.sendMessage(from, { text: '⚠️ 𝙰  𝚆𝚘𝚛𝚍  𝚂𝚎𝚊𝚛𝚌𝚑  𝚐𝚊𝚖𝚎  𝚒𝚜  𝚊𝚕𝚛𝚎𝚊𝚍𝚢  𝚊𝚌𝚝𝚒𝚟𝚎  𝚒𝚗  𝚝𝚑𝚒𝚜  𝚐𝚛𝚘𝚞𝚙!' }, { quoted: msg });
            return;
        }

        const { grid, words, wordLocations } = generateWordSearch(10, 5);

        global.wsgGames[from] = {
            grid,
            words,
            found: [],
            wordLocations,
            foundLocations: [],
            scores: {},
            timer: null
        };

        const imageBuffer = await renderWSGGrid(grid, []);
        const formattedWords = formatWordList(words, []);

        let caption = `⚡ 𝙿 𝚁 𝙸 𝙼 𝚄 𝚂   𝙼 𝙳 ⚡\n\n`;
        caption += `❖──────────【 𝚆𝙾𝚁𝙳  𝚂𝙴𝙰𝚁𝙲𝙷 】──────────❖\n`;
        caption += `│ 🎯 𝚁𝚎𝚙𝚕𝚢  𝚠𝚒𝚝𝚑  𝚝𝚑𝚎  𝚠𝚘𝚛𝚍  𝚝𝚘  𝚌𝚕𝚊𝚒𝚖  𝚙𝚘𝚒𝚗𝚝𝚜!\n`;
        caption += `│ ⏱️ 𝚃𝚒𝚖𝚎  𝙻𝚒𝚖𝚒𝚝 : 𝟹  𝙼𝚒𝚗𝚞𝚝𝚎𝚜\n`;
        caption += `❖─────────────────────────────❖\n\n`;
        caption += `📋 𝚆𝙾𝚁𝙳  𝙻𝙸𝚂𝚃:\n${formattedWords}\n\n`;
        caption += `└─ 𝑷𝒐𝒘𝒆𝒓𝒆𝒅 𝒃𝒚 𝑷𝒓𝒊𝒎𝒖𝒔 𝑴𝒅 ──`;

        await sock.sendMessage(from, { image: imageBuffer, caption }, { quoted: msg });

        global.wsgGames[from].timer = setTimeout(async () => {
            if (global.wsgGames[from]) {
                const game = global.wsgGames[from];
                let timeoutText = `⚡ 𝙿 𝚁 𝙸 𝙼 𝚄 𝚂   𝙼 𝙳 ⚡\n\n`;
                timeoutText += `❖──────────【 𝚃𝙸𝙼𝙴  𝚄𝙿 】──────────❖\n`;
                timeoutText += `│ ⏰ 𝚆𝚘𝚛𝚍  𝚂𝚎𝚊𝚛𝚌𝚑  𝚐𝚊𝚖𝚎  𝚑𝚊𝚜  𝚎𝚹𝚙𝚒𝚛𝚎𝚍!\n`;
                timeoutText += `❖─────────────────────────────❖\n\n`;
                timeoutText += `🏆 𝙵𝙸𝙽𝙰𝙻  𝚂𝙲𝙾𝚁𝙴𝚂:\n`;

                const sortedScores = Object.entries(game.scores).sort((a, b) => b[1] - a[1]);
                if (sortedScores.length > 0) {
                    sortedScores.forEach(([usr, pts]) => {
                        timeoutText += `│ 👤 @${usr.split('@')[0]} : ${pts} 𝚙𝚝𝚜\n`;
                    });
                } else {
                    timeoutText += `│ 𝙽𝚘  𝚘𝚗𝚎  𝚏𝚘𝚞𝚗𝚍  𝚊𝚗𝚢  𝚠𝚘𝚛𝚍𝚜.\n`;
                }
                timeoutText += `\n└─ 𝑷𝒐𝒘𝒆𝒓𝒆𝒅 𝒃𝒚 𝑷𝒓𝒊𝒎𝒖𝒔 𝑴𝒅 ──`;

                delete global.wsgGames[from];
                await sock.sendMessage(from, { text: timeoutText, mentions: sortedScores.map(s => s[0]) });
            }
        }, 180000);
    }
};
