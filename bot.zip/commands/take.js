import { downloadMediaMessage } from '@whiskeysockets/baileys';
import { writeFile, unlink } from 'fs/promises';
import path from 'path';
import crypto from 'crypto';

export default {
    name: 'take',
category: 'media',
    aliases: ['wm', 'rename'],
    description: 'Steal or re-brand sticker with hardcoded Lupin xmd watermark',
    execute: async (sock, msg, args, context) => {
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const mediaMsg = quoted?.stickerMessage || msg.message?.stickerMessage;

        if (!mediaMsg) {
            await sock.sendMessage(context.from, { text: '❌ Please reply to a sticker to rebrand it with Lupin xmd.' }, { quoted: msg });
            return;
        }

        try {
            const stream = await downloadMediaMessage(
                { message: { stickerMessage: mediaMsg } },
                'buffer',
                {},
                { logger: console }
            );

            const buffer = Buffer.isBuffer(stream) ? stream : Buffer.from(stream);
            await sock.sendMessage(context.from, { sticker: buffer }, { quoted: msg });

        } catch (e) {
            console.error('Take Error:', e);
            await sock.sendMessage(context.from, { text: `❌ Error: ${e.message}` }, { quoted: msg });
        }
    }
};
