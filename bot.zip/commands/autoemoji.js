import { loadSettings, saveSettings } from '../lib/database.js';

export default {
    name: 'autoemoji',
    aliases: ['autoreact', 'react'],
    description: 'Toggle auto emoji reaction for messages',
    category: 'settings',
    execute: async (sock, msg, args, context) => {
        const { from } = context;
        const opt = args[0] ? args[0].toLowerCase() : '';

        let settings = loadSettings() || {};

        if (opt === 'on' || opt === 'enable') {
            settings.autoEmoji = true;
            saveSettings(settings);
            return await sock.sendMessage(from, { text: '⚡ *Auto Emoji Reactions enabled!*' }, { quoted: msg });
        } else if (opt === 'off' || opt === 'disable') {
            settings.autoEmoji = false;
            saveSettings(settings);
            return await sock.sendMessage(from, { text: '⚡ *Auto Emoji Reactions disabled!*' }, { quoted: msg });
        } else {
            const status = settings.autoEmoji ? 'ON' : 'OFF';
            return await sock.sendMessage(from, { 
                text: `⚡ *Auto Emoji Status:* [ ${status} ]\n\nUsage:\n.autoemoji on\n.autoemoji off` 
            }, { quoted: msg });
        }
    }
};
