import { renderPixelBombGrid } from '../lib/pixelbombCanvas.js';

if (!global.pixelBombGames) {
    global.pixelBombGames = {};
}

export default {
    name: 'pixelbomb',
    description: 'Start a Pixel Bomb grid game in the group',
    category: 'games',
    execute: async (sock, msg, args, context) => {
        const { from, isGroup } = context;

        if (!isGroup) {
            await sock.sendMessage(from, { text: '⚠️ 𝚃𝚑𝚒𝚜  𝚐𝚊𝚖𝚎  𝚌𝚊𝚗  𝚘𝚗𝚕𝚢  𝚋𝚎  𝚙𝚕𝚊𝚢𝚎𝚍  𝚒𝚗  𝚐𝚛𝚘𝚞𝚙  𝚌𝚑𝚊𝚝𝚜!' }, { quoted: msg });
            return;
        }

        if (global.pixelBombGames[from]) {
            await sock.sendMessage(from, { text: '⚠️ 𝙰  𝙿𝚒𝚡𝚎𝚕  𝙱𝚘𝚖𝚋  𝚐𝚊𝚖𝚎  𝚒𝚜  𝚊𝚕𝚛𝚎𝚊𝚍𝚢  𝚊𝚌𝚝𝚒𝚟𝚎  𝚒𝚗  𝚝𝚑𝚒𝚜  𝚐𝚛𝚘𝚞𝚙!' }, { quoted: msg });
            return;
        }

        const size = 5;
        const total = size * size;
        const bombCount = 3;

        const indices = Array.from({ length: total }, (_, i) => i);
        indices.sort(() => Math.random() - 0.5);
        const bombs = new Set(indices.slice(0, bombCount));

        global.pixelBombGames[from] = {
            size,
            bombs,
            claimed: {},
            scores: {},
            timer: null
        };

        const imageBuffer = await renderPixelBombGrid(size, global.pixelBombGames[from].claimed, false);

        let caption = `⚡ 𝙿 𝚁 𝙸 𝙼 𝚄 𝚂   𝙼 𝙳 ⚡\n\n`;
        caption += `❖──────────【 𝙿𝙸𝚇𝙴𝙻  𝙱𝙾𝙼𝙱 】──────────❖\n`;
        caption += `│ 💣 𝙰𝚟𝚘𝚒𝚍  𝚝𝚑𝚎  𝚑𝚒𝚍𝚍𝚎𝚗  𝚋𝚘𝚖𝚋𝚜!\n`;
        caption += `│ 🎯 𝚃𝚢𝚙𝚎  #𝚌𝚕𝚊𝚒𝚖 <𝚗𝚞𝚖𝚋𝚎𝚛>  𝚝𝚘  𝚙𝚒𝚌𝚔  𝚊  𝚝𝚒𝚕𝚎.\n`;
        caption += `│ ⏱️ 𝚃𝚒𝚖𝚎  𝙻𝚒𝚖𝚒𝚝 : 𝟹  𝙼𝚒𝚗𝚞𝚝𝚎𝚜\n`;
        caption += `❖─────────────────────────────❖\n\n`;
        caption += `└─ 𝑷𝒐𝒘𝒆𝒓𝒆𝒅 𝒃𝒚 𝑷𝒓𝒊𝒎𝒖𝒔 𝑴𝒅 ──`;

        await sock.sendMessage(from, { image: imageBuffer, caption }, { quoted: msg });

        global.pixelBombGames[from].timer = setTimeout(async () => {
            if (global.pixelBombGames[from]) {
                const game = global.pixelBombGames[from];
                const revealBuffer = await renderPixelBombGrid(game.size, game.claimed, true);

                let timeoutText = `⚡ 𝙿 𝚁 𝙸 𝙼 𝚄 𝚂   𝙼 𝙳 ⚡\n\n`;
                timeoutText += `❖──────────【 𝚃𝙸𝙼𝙴  𝚄𝙿 】──────────❖\n`;
                timeoutText += `│ ⏰ 𝙿𝚒𝚡𝚎𝚕  𝙱𝚘𝚖𝚋  𝚐𝚊𝚖𝚎  𝚑𝚊𝚜  𝚎𝚹𝚙𝚒𝚛𝚎𝚍!\n`;
                timeoutText += `❖─────────────────────────────❖\n\n`;
                timeoutText += `🏆 𝙵𝙸𝙽𝙰𝙻  𝚂𝙲𝙾𝚁𝙴𝚂:\n`;

                const sortedScores = Object.entries(game.scores).sort((a, b) => b[1] - a[1]);
                if (sortedScores.length > 0) {
                    sortedScores.forEach(([usr, pts]) => {
                        timeoutText += `│ 👤 @${usr.split('@')[0]} : ${pts} 𝚙𝚝𝚜\n`;
                    });
                } else {
                    timeoutText += `│ 𝙽𝚘  𝚘𝚗𝚎  𝚌𝚕𝚊𝚒𝚖𝚎𝚍  𝚊𝚗𝚢  𝚝𝚒𝚕𝚎𝚜.\n`;
                }
                timeoutText += `\n└─ 𝑷𝒐𝒘𝒆𝒓𝒆𝒅 𝒃𝒚 𝑷𝒓𝒊𝒎𝒖𝒔 𝑴𝒅 ──`;

                delete global.pixelBombGames[from];
                await sock.sendMessage(from, { image: revealBuffer, caption: timeoutText, mentions: sortedScores.map(s => s[0]) });
            }
        }, 180000);
    }
};

export async function handleClaim(sock, msg, args, context) {
    const { from, sender } = context;

    if (!global.pixelBombGames || !global.pixelBombGames[from]) {
        await sock.sendMessage(from, { text: '⚠️ 𝙽𝚘  𝚊𝚌𝚝𝚒𝚟𝚎  𝙿𝚒𝚡𝚎𝚕  𝙱𝚘𝚖𝚋  𝚐𝚊𝚖𝚎!  𝚂𝚝𝚊𝚛𝚝  𝚘𝚗𝚎  𝚠𝚒𝚝𝚑  #𝚙𝚒𝚡𝚎𝚕𝚋𝚘𝚖𝚋' }, { quoted: msg });
        return;
    }

    const game = global.pixelBombGames[from];
    const tileNum = parseInt(args[0], 10);

    if (isNaN(tileNum) || tileNum < 1 || tileNum > game.size * game.size) {
        await sock.sendMessage(from, { text: `⚠️ 𝙿𝚕𝚎𝚊𝚜𝚎  𝚙𝚛𝚘𝚟𝚒𝚍𝚎  𝚊  𝚟𝚊𝚕𝚒𝚍  𝚝𝚒𝚕𝚎  𝚗𝚞𝚖𝚋𝚎𝚛  𝚋𝚎𝚝𝚠𝚎𝚎𝚗  𝟷  𝚊𝚗𝚍  ${game.size * game.size}!` }, { quoted: msg });
        return;
    }

    const tileIdx = tileNum - 1;
    if (game.claimed[tileIdx]) {
        await sock.sendMessage(from, { text: `⚠️ 𝚃𝚒𝚕𝚎  ${tileNum}  𝚑𝚊𝚜  𝚊𝚕𝚛𝚎𝚊𝚍𝚢  𝚋𝚎𝚎𝚗  𝚌𝚕𝚊𝚒𝚖𝚎𝚍!` }, { quoted: msg });
        return;
    }

    const senderNum = sender.split('@')[0];

    if (game.bombs.has(tileIdx)) {
        game.claimed[tileIdx] = { user: sender, type: 'bomb' };
        game.scores[sender] = (game.scores[sender] || 0) - 10;

        const revealBuffer = await renderPixelBombGrid(game.size, game.claimed, true);

        let bombText = `⚡ 𝙿 𝚁 𝙸 𝙼 𝚄 𝚂   𝙼 𝙳 ⚡\n\n`;
        bombText += `❖──────────【 💥 𝙱 𝙾 𝙾 𝙼 💥 】──────────❖\n`;
        bombText += `│ 💣 @${senderNum}  𝚑𝚒𝚝  𝚊  𝙱𝙾𝙼𝙱  𝚘𝚗  𝚝𝚒𝚕𝚎  ${tileNum}!\n`;
        bombText += `│ 📉 -𝟷𝟶  𝙿𝚘𝚒𝚗𝚝𝚜\n`;
        bombText += `❖─────────────────────────────❖\n\n`;

        const totalTiles = game.size * game.size;
        const claimedTiles = Object.keys(game.claimed).length;

        if (claimedTiles === totalTiles) {
            clearTimeout(game.timer);
            bombText += `🎉 𝙰𝚕𝚕  𝚝𝚒𝚕𝚎𝚜  𝚑𝚊𝚟𝚎  𝚋𝚎𝚎𝚗  𝚌𝚕𝚊𝚒𝚖𝚎𝚍!  𝙶𝚊𝚖𝚎  𝙾𝚟𝚎𝚛!\n\n`;
            bombText += `🏆 𝙵𝙸𝙽𝙰𝙻  𝚂𝙲𝙾𝚁𝙴𝚂:\n`;
            const sortedScores = Object.entries(game.scores).sort((a, b) => b[1] - a[1]);
            sortedScores.forEach(([usr, pts]) => {
                bombText += `│ 👤 @${usr.split('@')[0]} : ${pts} 𝚙𝚝𝚜\n`;
            });
            delete global.pixelBombGames[from];
            bombText += `\n└─ 𝑷𝒐𝒘𝒆𝒓𝒆𝒅 𝒃𝒚 𝑷𝒓𝒊𝒎𝒖𝒔 𝑴𝒅 ──`;
            await sock.sendMessage(from, { image: revealBuffer, caption: bombText, mentions: [sender, ...Object.keys(game.scores)] }, { quoted: msg });
        } else {
            bombText += `└─ 𝑷𝒐𝒘𝒆𝒓𝒆𝒅 𝒃𝒚 𝑷𝒓𝒊𝒎𝒖𝒔 𝑴𝒅 ──`;
            await sock.sendMessage(from, { image: revealBuffer, caption: bombText, mentions: [sender] }, { quoted: msg });
        }
    } else {
        game.claimed[tileIdx] = { user: sender, type: 'safe' };
        game.scores[sender] = (game.scores[sender] || 0) + 10;

        const updatedBuffer = await renderPixelBombGrid(game.size, game.claimed, false);

        let safeText = `⚡ 𝙿 𝚁 𝙸 𝙼 𝚄 𝚂   𝙼 𝙳 ⚡\n\n`;
        safeText += `❖──────────【 💎 𝚂 𝙰 𝙵 𝙴 💎 】──────────❖\n`;
        safeText += `│ 🎯 @${senderNum}  𝚌𝚕𝚊𝚒𝚖𝚎𝚍  𝚝𝚒𝚕𝚎  ${tileNum}!\n`;
        safeText += `│ 📈 +𝟷𝟶  𝙿𝚘𝚒𝚗𝚝𝚜\n`;
        safeText += `❖─────────────────────────────❖\n\n`;

        const totalTiles = game.size * game.size;
        const claimedTiles = Object.keys(game.claimed).length;

        if (claimedTiles === totalTiles) {
            clearTimeout(game.timer);
            const revealBuffer = await renderPixelBombGrid(game.size, game.claimed, true);
            safeText += `🎉 𝙰𝚕𝚕  𝚝𝚒𝚕𝚎𝚜  𝚑𝚊𝚟𝚎  𝚋𝚎𝚎𝚗  𝚌𝚕𝚊𝚒𝚖𝚎𝚍!  𝙶𝚊𝚖𝚎  𝙾𝚟𝚎𝚛!\n\n`;
            safeText += `🏆 𝙵𝙸𝙽𝙰𝙻  𝚂𝙲𝙾𝚁𝙴𝚂:\n`;
            const sortedScores = Object.entries(game.scores).sort((a, b) => b[1] - a[1]);
            sortedScores.forEach(([usr, pts]) => {
                safeText += `│ 👤 @${usr.split('@')[0]} : ${pts} 𝚙𝚝𝚜\n`;
            });
            delete global.pixelBombGames[from];
            safeText += `\n└─ 𝑷𝒐𝒘𝒆𝒓𝒆𝒅 𝒃𝒚 𝑷𝒓𝒊𝒎𝒖𝒔 𝑴𝒅 ──`;
            await sock.sendMessage(from, { image: revealBuffer, caption: safeText, mentions: [sender, ...Object.keys(game.scores)] }, { quoted: msg });
        } else {
            safeText += `└─ 𝑷𝒐𝒘𝒆𝒓𝒆𝒅 𝒃𝒚 𝑷𝒓𝒊𝒎𝒖𝒔 𝑴𝒅 ──`;
            await sock.sendMessage(from, { image: updatedBuffer, caption: safeText, mentions: [sender] }, { quoted: msg });
        }
    }
}
