import { addSudoPlayers } from '../lib/sudoGameManager.js';
import { checkIsSudo } from '../lib/isSudoCheck.js';

export default {
    name: 'sudogame',
    aliases: ['sg', 'addplayer'],
    category: 'games',
    description: 'Grant players access to active game commands.',
    execute: async (sock, msg, args, context) => {
        const { from, sender } = context;
        const isUserSudo = checkIsSudo(sender);

        if (!isUserSudo) {
            await sock.sendMessage(from, { text: '🚫 *ACCESS DENIED:* Only global bot Sudo users can manage game permissions!' }, { quoted: msg });
            return;
        }

        const game = global.activeGames?.[from];
        if (!game) {
            await sock.sendMessage(from, { text: '⚠️ *No active game session found in this chat.* Start a game first!' }, { quoted: msg });
            return;
        }

        let mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
        if (quotedParticipant && !mentioned.includes(quotedParticipant)) {
            mentioned.push(quotedParticipant);
        }

        if (mentioned.length === 0 && args[0]) {
            const rawNumber = args[0].replace(/[^0-9]/g, '');
            if (rawNumber) mentioned.push(rawNumber + '@s.whatsapp.net');
        }

        if (mentioned.length === 0) {
            await sock.sendMessage(from, { text: '⚠️ *Mention or reply to a user* to grant them game access!\nExample: `#sudogame @user`' }, { quoted: msg });
            return;
        }

        addSudoPlayers(from, mentioned);

        const mentionsList = mentioned.map(m => `@${m.split('@')[0]}`).join(', ');
        const text = `⚡ *S U D O   G A M E   G R A N T E D* ⚡\n\n🎮 *Authorized Players:* ${mentionsList}\n🔥 You now have full clearance to execute game commands in this match!`;

        await sock.sendMessage(from, { text, mentions: mentioned }, { quoted: msg });
    }
};
