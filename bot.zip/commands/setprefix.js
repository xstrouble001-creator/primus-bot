import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import config from '../config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'setprefix',
    description: 'To change prefix, owner only command',
    category: 'settings',
    execute: async (sock, msg, args, context) => {
        const { from, isOwner } = context;
        if (!isOwner) {
            return await sock.sendMessage(from, { text: '❌ This command is restricted to the bot owner.' }, { quoted: msg });
        }

        const newPrefix = args[0];
        if (!newPrefix) {
            return await sock.sendMessage(from, { text: `💡 Usage: ${config.prefix}setprefix <new_prefix>` }, { quoted: msg });
        }

        config.prefix = newPrefix;

        try {
            const configPath = path.resolve(__dirname, '../config.js');
            let configContent = fs.readFileSync(configPath, 'utf8');
            configContent = configContent.replace(/prefix\s*:\s*['"`].*?['"`]/, () => `prefix: '${newPrefix}'`);
            fs.writeFileSync(configPath, configContent, 'utf8');
        } catch (err) {
            console.error('Failed to update config.js file:', err);
        }

        await sock.sendMessage(from, { text: `✅ Prefix successfully updated and saved to: ${newPrefix}` }, { quoted: msg });
    }
};
