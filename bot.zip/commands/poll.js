export default {
    name: 'poll',
    description: 'Create an interactive group poll with custom options',
    category: 'group',
    execute: async (sock, msg, args, context) => {
        const { from } = context;
        const input = args.join(' ');
        const parts = input.split('|').map(p => p.trim()).filter(p => p.length > 0);

        if (parts.length < 3) {
            return sock.sendMessage(from, { text: '⚠️ Usage: .poll Question | Option 1 | Option 2 [| Option 3...]' }, { quoted: msg });
        }

        const question = parts[0];
        const values = parts.slice(1);

        await sock.sendMessage(from, {
            poll: {
                name: question,
                values: values,
                selectableCount: 1
            }
        });
    }
};
