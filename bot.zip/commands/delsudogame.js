import { endSudoGame } from '../lib/sudoGameManager.js';
import { checkIsSudo } from '../lib/isSudoCheck.js';

export default {
    name: 'delsudogame',
    aliases: ['dsg', 'stopgame'],
    category: 'games',
    description: 'Revoke all gaming access and terminate the current game session.',
    execute: async (sock, msg, args, context) => {
        const { from, sender } = context;
        const isUserSudo = checkIsSudo(sender);

        if (!isUserSudo) {
            await sock.sendMessage(from, { text: '🚫 *ACCESS DENIED:* Only global bot Sudo users can revoke game permissions!' }, { quoted: msg });
            return;
        }

        if (!global.activeGames?.[from]) {
            await sock.sendMessage(from, { text: '⚠️ *No active game session to terminate.*' }, { quoted: msg });
            return;
        }

        endSudoGame(from);

        const text = `🚨 *G A M E   T E R M I N A T E D* 🚨\n\n🛑 All active game permissions have been revoked.\nThe match has been stopped by Sudo command.`;

        await sock.sendMessage(from, { text }, { quoted: msg });
    }
};
