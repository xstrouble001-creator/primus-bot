export default {
    name: 'mute',
    aliases: ['unmute', 'close', 'open'],
    description: 'Restrict group chat permissions to admins only or open to all members',
    category: 'admin',
    execute: async (sock, msg, args, context) => {
        const { from, isGroup } = context;

        if (!isGroup) {
            return sock.sendMessage(from, { text: '⚠️ This command can only be used in groups.' }, { quoted: msg });
        }

        const textCommand = msg.message?.conversation?.split(' ')[0]?.replace('.', '') || 
                            msg.message?.extendedTextMessage?.text?.split(' ')[0]?.replace('.', '') || 'mute';

        const isClose = textCommand === 'mute' || textCommand === 'close';

        try {
            await sock.groupSettingUpdate(from, isClose ? 'announcement' : 'not_announcement');
            const stateText = isClose 
                ? '🔒 Quadrant muted. Only administrators can send messages.' 
                : '🔓 Quadrant unmuted. All members can now transmit messages.';
            
            await sock.sendMessage(from, { text: stateText }, { quoted: msg });
        } catch (e) {
            await sock.sendMessage(from, { text: '❌ Action failed. Ensure the bot is an administrator.' }, { quoted: msg });
        }
    }
};
