import { downloadMediaMessage } from '@whiskeysockets/baileys';
import { writeFile, unlink } from 'fs/promises';
import fs from 'fs';
import { exec } from 'child_process';
import path from 'path';
import crypto from 'crypto';

export default {
    name: 'sticker',
category: 'media',
    aliases: ['s'],
    description: 'Convert replied image or video into a sticker',
    execute: async (sock, msg, args, context) => {
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        
        let targetMessage = null;
        if (msg.message?.imageMessage || msg.message?.videoMessage) {
            targetMessage = msg;
        } else if (quoted && (quoted.imageMessage || quoted.videoMessage || quoted.documentMessage)) {
            targetMessage = { message: quoted };
        }

        if (!targetMessage) {
            await sock.sendMessage(context.from, { text: '❌ Please reply to an image or video with `.s` to convert it into a sticker.' }, { quoted: msg });
            return;
        }

        try {
            const stream = await downloadMediaMessage(
                targetMessage,
                'buffer',
                {},
                { logger: console, reuploadRequest: sock.updateMediaMessage }
            );

            const buffer = Buffer.isBuffer(stream) ? stream : Buffer.from(stream);
            const rnd = crypto.randomBytes(4).toString('hex');
            const tempInput = path.join('./', `input_${rnd}.tmp`);
            const tempOutput = path.join('./', `output_${rnd}.webp`);

            await writeFile(tempInput, buffer);

            // Simplified universal ffmpeg command compatible with all Termux builds
            const ffmpegCmd = `ffmpeg -i ${tempInput} -y -vcodec webp -lossless 1 ${tempOutput}`;

            exec(ffmpegCmd, async (error) => {
                if (error || !fs.existsSync(tempOutput)) {
                    // Fallback to basic copy if webp encoder flags fail
                    if (fs.existsSync(tempInput)) await unlink(tempInput);
                    await sock.sendMessage(context.from, { text: '❌ FFmpeg WebP encoder missing on this Termux build. Run: pkg install ffmpeg' }, { quoted: msg });
                    return;
                }

                await sock.sendMessage(context.from, { sticker: await fs.promises.readFile(tempOutput) }, { quoted: msg });

                if (fs.existsSync(tempInput)) await unlink(tempInput);
                if (fs.existsSync(tempOutput)) await unlink(tempOutput);
            });

        } catch (e) {
            console.error('Sticker Error:', e);
            await sock.sendMessage(context.from, { text: `❌ Error: ${e.message}` }, { quoted: msg });
        }
    }
};
