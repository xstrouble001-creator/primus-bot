export default {
    name: 'add',
category: 'group',
    description: 'Add a user to the group via phone number or reply',
    groupOnly: true,
    execute: async (sock, msg, args, context) => {
        const { from, isGroup } = context;
        if (!isGroup) {
            await sock.sendMessage(from, { text: '⚡ [ERROR] This command can only be executed inside group sectors.' }, { quoted: msg });
            return;
        }

        // Extract target from arguments or quoted message sender
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const quotedSender = msg.message?.extendedTextMessage?.contextInfo?.participant;
        
        let targetNum = args[0] ? args[0].replace(/[^0-9]/g, '') : '';
        if (!targetNum && quotedSender) {
            targetNum = quotedSender.split('@')[0].replace(/[^0-9]/g, '');
        }

        if (!targetNum) {
            await sock.sendMessage(from, { text: '⚡ [ERROR] Provide a phone number or reply to a user.\nExample: `.add 2348039336009`' }, { quoted: msg });
            return;
        }

        const userJid = `${targetNum}@s.whatsapp.net`;

        try {
            await sock.sendMessage(from, { text: `🔄 [INJECTING] Adding +${targetNum} to group sector...` }, { quoted: msg });
            
            const response = await sock.groupParticipantsUpdate(from, [userJid], 'add');
            
            if (response && response[0]?.status === '200') {
                await sock.sendMessage(from, { text: `✅ [SUCCESS] Target +${targetNum} successfully integrated into the group.` }, { quoted: msg });
            } else if (response && response[0]?.status === '403') {
                await sock.sendMessage(from, { text: `⚠️ [BLOCKED] Could not add +${targetNum}. User's privacy settings restrict direct group additions (invite sent instead if available).` }, { quoted: msg });
            } else {
                await sock.sendMessage(from, { text: `✅ [EXECUTED] Group participant update dispatched for +${targetNum}.` }, { quoted: msg });
            }

        } catch (e) {
            console.error('Add Command Error:', e);
            await sock.sendMessage(from, { text: `❌ [INJECTION FAILED]: Ensure the bot is a group admin.` }, { quoted: msg });
        }
    }
};
