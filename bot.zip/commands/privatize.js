import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import config from '../config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
    name: 'privatize',
    description: 'To restrict a command to be owner only command',
    category: 'settings',
    execute: async (sock, msg, args, context) => {
        const { from, isOwner } = context;
        if (!isOwner) {
            return await sock.sendMessage(from, { text: '⚠️ [ACCESS DENIED] Root privilege required to lock command modules.' }, { quoted: msg });
        }

        const cmdName = args[0]?.toLowerCase();
        if (!cmdName) {
            return await sock.sendMessage(from, { text: `⚡ [SYNTAX ERROR] Usage: ${config.prefix}privatize <command_name>` }, { quoted: msg });
        }

        if (!config.privateCommands) config.privateCommands = [];

        if (config.privateCommands.includes(cmdName)) {
            return await sock.sendMessage(from, { text: `🛡️ [NOTICE] Module [${cmdName}] is already isolated to owner-only clearance.` }, { quoted: msg });
        }

        config.privateCommands.push(cmdName);

        try {
            const configPath = path.resolve(__dirname, '../config.js');
            let configContent = fs.readFileSync(configPath, 'utf8');
            
            const privArrayStr = `privateCommands: ${JSON.stringify(config.privateCommands, null, 4)}`;
            if (configContent.includes('privateCommands')) {
                configContent = configContent.replace(/privateCommands\s*:\s*\[[\s\S]*?\]/, privArrayStr);
            } else {
                configContent = configContent.replace(/export default\s*{/, `export default {\n    ${privArrayStr},`);
            }
            fs.writeFileSync(configPath, configContent, 'utf8');
        } catch (err) {
            console.error('Failed to update config.js file:', err);
        }

        await sock.sendMessage(from, { text: `🔒 [ISOLATION COMPLETE] Module [${cmdName}] locked behind owner-only clearance.` }, { quoted: msg });
    }
};
