import { loadSettings, saveSettings } from '../lib/database.js';

export default {
    name: 'antibot',
category: 'group',
    description: 'Toggle antibot filter to prevent foreign bots from spamming messages',
    groupOnly: true,
    execute: async (sock, msg, args, context) => {
        const { from } = context;
        const settings = loadSettings() || {};
        if (!settings.antibotGroups) settings.antibotGroups = [];

        const isEnabled = settings.antibotGroups.includes(from);
        const action = args[0]?.toLowerCase();

        if (action === 'on' && !isEnabled) {
            settings.antibotGroups.push(from);
            saveSettings(settings);
            await sock.sendMessage(from, { text: '🛡️ [ANTIBOT ACTIVATED] Foreign bot transmissions will now be neutralized.' }, { quoted: msg });
        } else if (action === 'off' && isEnabled) {
            settings.antibotGroups = settings.antibotGroups.filter(id => id !== from);
            saveSettings(settings);
            await sock.sendMessage(from, { text: '⚠️ [ANTIBOT DEACTIVATED] Foreign bot activity permitted.' }, { quoted: msg });
        } else {
            await sock.sendMessage(from, { text: `🛡️ [ANTIBOT STATUS] Currently: *${isEnabled ? 'ACTIVE' : 'INACTIVE'}*\nUse \`.antibot on\` or \`.antibot off\` to toggle.` }, { quoted: msg });
        }
    }
};
