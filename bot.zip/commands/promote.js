export default {
    name: 'promote',
    description: 'Elevate a target participant to group administrator',
    category: 'admin',
    execute: async (sock, msg, args, context) => {
        const { from, isGroup } = context;

        if (!isGroup) {
            return sock.sendMessage(from, { text: '⚠️ This command can only be used in groups.' }, { quoted: msg });
        }

        const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
        const targetUser = contextInfo?.mentionedJid?.[0] || contextInfo?.participant;

        if (!targetUser) {
            return sock.sendMessage(from, { text: '⚠️ Usage: Reply to or tag the user you want to promote.' }, { quoted: msg });
        }

        try {
            await sock.groupParticipantsUpdate(from, [targetUser], 'promote');
            await sock.sendMessage(from, { 
                text: `⚡ Privileges elevated for @${targetUser.split('@')[0]}. User is now an administrator.`,
                mentions: [targetUser]
            }, { quoted: msg });
        } catch (e) {
            await sock.sendMessage(from, { text: '❌ Promotion failed. Ensure the bot has administrative privileges.' }, { quoted: msg });
        }
    }
};
