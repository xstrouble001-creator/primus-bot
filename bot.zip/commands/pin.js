import { sendAnimatedLoader } from '../lib/animator.js';

export default {
    name: 'pin',
    aliases: ['pingroup'],
    description: 'Pin a quoted message in the group',
    category: 'admin',
    execute: async (sock, msg, args, context) => {
        const { from, isGroup } = context;

        if (!isGroup) {
            return sock.sendMessage(from, { text: '│ ❌ This command can only be used in group chats.' }, { quoted: msg });
        }

        const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
        const quotedKey = contextInfo?.stanzaId;
        const quotedParticipant = contextInfo?.participant;

        if (!quotedKey) {
            return sock.sendMessage(from, { text: '│ ❌ Please reply to the message you want to pin.' }, { quoted: msg });
        }

        try {
            const keyToPin = {
                remoteJid: from,
                fromMe: quotedParticipant ? quotedParticipant.includes(sock.user.id.split(':')[0]) : false,
                id: quotedKey,
                participant: quotedParticipant
            };

            await sock.chatModify({
                pin: {
                    type: 1, // 1 = PIN
                    time: 604800 // 7 days in seconds
                }
            }, keyToPin);

            const loaderKey = await sendAnimatedLoader(sock, from, msg);

            let text = `⚡ 𝙿 𝚁 𝙸 𝙼 𝚄 𝚂   𝙼 𝙳 ⚡\n\n`;
            text += `❖──────────【 𝙼𝙴𝚂𝚂𝙰𝙶𝙴  𝙿𝙸𝙽𝙽𝙴𝙳 】──────────❖\n│\n`;
            text += `│ 📌 𝚂𝚝𝚊𝚝𝚞𝚜 : Message pinned successfully.\n│\n`;
            text += `❖─────────────────────────────❖\n\n`;
            text += `└─ 𝑷𝒐𝒘𝒆𝒓𝒆𝒅 𝒃𝒚 𝑷𝒓𝒊𝒎𝒖𝒔 𝑴𝒅 ──`;

            await sock.sendMessage(from, { text, edit: loaderKey });
        } catch (err) {
            console.error('❌ [PIN ERROR]:', err);
            await sock.sendMessage(from, { text: '│ ❌ Failed to pin message. Make sure the bot is an Admin in this group.' }, { quoted: msg });
        }
    }
};
