export default {
    botName: 'Primus Md',
    prefix: '#',
    sessions: [
      
    ],
    devNumber: '2347053852949',
    omdbApiKey: '760bd7f3',
    owner: ['2349131719077@s.whatsapp.net'],
    ownerNumber: ['2347053852949'],
    workMode: 'private',
    sudo: [
    "34167052083205@s.whatsapp.net",
    "105480823259328@s.whatsapp.net",
    "235051363094577@s.whatsapp.net"
],
    privateCommands: [
    "musicvideo",
    "vv",
    "setowner"
],
    banners: {
        main: './assets/menu.jpeg',
        general: './assets/general.jpeg',
        admin: './assets/admin.jpeg',
        group: './assets/group.jpeg',
        media: './assets/media.jpeg',
        owner: './assets/owner.jpeg'
    }
};
